﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MenuImplementation
{
    interface IExceptionLogger
    {
        void addErrorLog(System.Exception ex);

    }
}
